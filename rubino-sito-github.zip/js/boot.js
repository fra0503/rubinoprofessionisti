location.replace("/panoramica");
