import { $, esc, renderHeader, requireSession } from "./core.js?v=4";
const ctx = await requireSession();
if (ctx) {
  renderHeader("panoramica", ctx.profile, ctx.sb);
  if (ctx.profile.role === "admin") {
    // Conteggi reali dal database (funzione admin_overview, protetta lato server)
    const { data, error } = await ctx.sb.rpc("admin_overview");
    if (!error && data) {
      const n = (o, ...k) => k.reduce((s, x) => s + Number(o?.[x] || 0), 0);
      const items = [[n(data.properties, "approved"), "Immobili approvati"], [n(data.properties, "submitted", "in_review"), "In revisione"],
        [n(data.requests, "new", "matching"), "Richieste attive"], [Number(data.professionals_active || 0), "Professionisti attivi"], [Number(data.invites_pending || 0), "Inviti in attesa"]];
      $("#stats").innerHTML = items.map(([v, l]) => `<div class="stat"><b>${esc(v)}</b><span>${esc(l)}</span></div>`).join("");
      $("#stats").hidden = false;
    }
  }
}
