// Registro delle attività (solo amministratore, sola lettura). Il registro non è modificabile da nessun utente.
import { $, downloadCsv, esc, fmtDate, renderHeader, requireSession, toast } from "./core.js?v=4";
const ctx = await requireSession();
if (ctx && ctx.profile.role !== "admin") location.replace("/panoramica");
else if (ctx) {
  renderHeader("attivita", ctx.profile, ctx.sb);
  const PAGE = 25, S = { page: 0, ent: "", q: "", from: "", to: "" }, list = $("#list");
  const ENT = { properties: "Immobile", client_requests: "Richiesta", matches: "Abbinamento", profiles: "Professionista", invites: "Invito" };
  const ACT = { insert: "creato", update: "aggiornato", delete: "eliminato" };
  const SPECIAL = { "invite.create": "Invito creato", "invite.regenerate": "Invito rigenerato", "invite.revoke": "Invito revocato", "invite.accept": "Invito accettato (account attivato)", "account.deactivate": "Account disattivato", "account.reactivate": "Account riattivato", "account.set_role": "Ruolo modificato", "account.export": "Dati account esportati", "account.delete": "Account eliminato", "admin.bootstrap": "Primo amministratore creato" };
  const label = (a) => SPECIAL[a] || (a.includes(".") ? `${ENT[a.split(".")[0]] || a.split(".")[0]} ${ACT[a.split(".")[1]] || a.split(".")[1]}` : a);
  const STATUS = { draft: "bozza", submitted: "inviato", in_review: "in revisione", approved: "approvato", rejected: "rifiutato", archived: "archiviato", new: "nuova", matching: "in ricerca", matched: "abbinata", closed: "chiusa", suggested: "da valutare", confirmed: "confermato", dismissed: "respinto" };
  const det = (d) => [d.title, d.status && "stato: " + (STATUS[d.status] || d.status), d.role && "ruolo: " + d.role, d.active != null && "attivo: " + (d.active === "true" || d.active === true ? "sì" : "no"), d.email, d.name].filter(Boolean).join(" · ");
  const filtered = (q) => { if (S.ent) q = q.eq("entity_type", S.ent); const s = S.q.replace(/[,%()*\\]/g, " ").trim(); if (s) q = q.or(`action.ilike.%${s}%,entity_type.ilike.%${s}%`);
    if (S.from) q = q.gte("created_at", new Date(S.from + "T00:00:00").toISOString()); if (S.to) q = q.lte("created_at", new Date(S.to + "T23:59:59").toISOString()); return q; };
  const actors = async (rows) => { const ids = [...new Set(rows.map((r) => r.actor_id).filter(Boolean))], m = {}; if (ids.length) { const { data } = await ctx.sb.from("profiles").select("id,full_name").in("id", ids); (data || []).forEach((p) => (m[p.id] = p.full_name)); } return m; };
  async function load() {
    list.innerHTML = '<p class="state">Caricamento…</p>';
    const { data, count, error } = await filtered(ctx.sb.from("activity_logs").select("id,actor_id,action,entity_type,entity_id,details,created_at", { count: "exact" })).order("created_at", { ascending: false }).range(S.page * PAGE, S.page * PAGE + PAGE - 1);
    if (error) { list.innerHTML = '<p class="state err">Impossibile caricare il registro. Riprova tra poco.</p>'; return; }
    if (!data.length) { list.innerHTML = '<div class="state"><p>Nessuna attività corrisponde ai filtri.</p></div>'; $("#pager").hidden = true; return; }
    const nm = await actors(data);
    list.innerHTML = `<div class="tablewrap"><table><thead><tr><th>Data</th><th>Chi</th><th>Azione</th><th>Record</th><th>Dettagli</th></tr></thead><tbody>${data.map((r) => `<tr><td>${esc(fmtDate(r.created_at))}</td><td>${esc(nm[r.actor_id] || (r.actor_id ? "Account eliminato" : "Sistema"))}</td><td>${esc(label(r.action))}</td><td>${esc(ENT[r.entity_type] || r.entity_type)} <span class="pmeta">${esc((r.entity_id || "").slice(0, 8))}</span></td><td>${esc(det(r.details || {}))}</td></tr>`).join("")}</tbody></table></div>`;
    const pages = Math.max(1, Math.ceil(count / PAGE)); $("#pager").hidden = pages < 2; $("#pinfo").textContent = `Pagina ${S.page + 1} di ${pages} · ${count} voci`; $("#prev").disabled = S.page === 0; $("#next").disabled = S.page >= pages - 1;
  }
  for (const [id, k] of [["ent", "ent"], ["from", "from"], ["to", "to"]]) $("#" + id).addEventListener("change", (e) => { S[k] = e.target.value; S.page = 0; load(); });
  let t; $("#search").addEventListener("input", (e) => { clearTimeout(t); t = setTimeout(() => { S.q = e.target.value; S.page = 0; load(); }, 300); });
  $("#prev").addEventListener("click", () => { S.page--; load(); scrollTo(0, 0); }); $("#next").addEventListener("click", () => { S.page++; load(); scrollTo(0, 0); });
  $("#csv").addEventListener("click", async () => {
    const { data, error } = await filtered(ctx.sb.from("activity_logs").select("actor_id,action,entity_type,entity_id,details,created_at")).order("created_at", { ascending: false }).range(0, 4999);
    if (error) return toast("Esportazione non riuscita."); const nm = await actors(data);
    downloadCsv("attivita.csv", ["Data", "Chi", "Azione", "Tipo record", "ID record", "Dettagli"], data.map((r) => [r.created_at, nm[r.actor_id] || (r.actor_id ? "Account eliminato" : "Sistema"), label(r.action), ENT[r.entity_type] || r.entity_type, r.entity_id, det(r.details || {})]));
  });
  $("#ret").addEventListener("submit", async (e) => { e.preventDefault(); const d = Number($("#days").value); if (!Number.isInteger(d) || d < 30) return toast("Indica almeno 30 giorni."); const { error } = await ctx.sb.rpc("admin_set_retention", { p_days: d }); toast(error ? "Impostazione non riuscita: " + error.message : `Conservazione del registro impostata a ${d} giorni.`); });
  await load();
}
