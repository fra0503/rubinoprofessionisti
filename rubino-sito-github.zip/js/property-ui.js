// Interfaccia condivisa per gli immobili: schede, dettaglio, modulo di modifica con foto, azioni di stato.
import { $, esc, toast } from "./core.js?v=4";
export const STATUS = { draft: "Bozza", submitted: "Inviato", in_review: "In revisione", approved: "Approvato", rejected: "Rifiutato", archived: "Archiviato" };
export const CATS = ["Residenziale", "Commerciale", "Terreno", "Altro"];
const ENERGY = ["A4", "A3", "A2", "A1", "B", "C", "D", "E", "F", "G", "In attesa"];
const HEAT = ["Autonomo", "Centralizzato", "Pompa di calore", "Assente", "Altro"];
const BUCKET = "property-files", MAX_PHOTOS = 20, MIN_PHOTOS = 3, MAX_BYTES = 5 * 1024 * 1024;
const EXT = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };
const eur = new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR", maximumFractionDigits: 0 });
export const price = (p, t) => (p == null ? "Prezzo su richiesta" : eur.format(p) + (t === "rent" ? " al mese" : ""));
export const badge = (s) => `<span class="badge b-${esc(s)}">${esc(STATUS[s] || s)}</span>`;
const yn = (b) => (b ? "Sì" : "No");

export async function signed(sb, paths) {
  const m = {}; if (!paths.length) return m;
  const { data } = await sb.storage.from(BUCKET).createSignedUrls(paths, 3600); // link a scadenza, bucket privato
  (data || []).forEach((d) => { if (d.signedUrl) m[d.path] = d.signedUrl; });
  return m;
}
// Etichetta del proprietario: i professionisti vedono solo il codice anonimo; l'admin anche il nome reale.
export async function ownerLabels(ctx, rows) {
  const out = {}, ids = rows.map((r) => r.id); if (!ids.length) return out;
  const { data: al } = await ctx.sb.from("property_owner_alias").select("property_id,alias_code").in("property_id", ids);
  (al || []).forEach((a) => (out[a.property_id] = `Professionista ${a.alias_code}`));
  if (ctx.profile.role === "admin") {
    const { data: pr } = await ctx.sb.from("profiles").select("id,full_name,alias_code").in("id", [...new Set(rows.map((r) => r.submitted_by))]);
    const nm = {}; (pr || []).forEach((p) => (nm[p.id] = `${p.full_name} · ${p.alias_code}`));
    rows.forEach((r) => { if (nm[r.submitted_by]) out[r.id] = nm[r.submitted_by]; });
  }
  rows.forEach((r) => { if (r.submitted_by === ctx.user.id) out[r.id] = "Tu"; });
  return out;
}
export const firstPaths = (rows) => rows.flatMap((r) => [...(r.property_photos || [])].sort((a, b) => a.position - b.position).slice(0, 1).map((x) => x.storage_path));
export function cardsHtml(rows, urls, owners, ctx) {
  return rows.map((r) => {
    const ph = [...(r.property_photos || [])].sort((a, b) => a.position - b.position)[0], u = ph && urls[ph.storage_path];
    const showStatus = r.submitted_by === ctx.user.id || ctx.profile.role === "admin";
    return `<button class="pcard" type="button" data-id="${esc(r.id)}"><span class="pphoto">${u ? `<img src="${esc(u)}" alt="" loading="lazy">` : '<span class="noph" aria-hidden="true">⌂</span>'}${showStatus ? badge(r.status) : ""}</span>
      <span class="pbody"><b class="ptitle">${esc(r.title)}</b><span class="pmeta">${esc(r.municipality)} · ${esc(r.category)} · ${r.listing_type === "rent" ? "Affitto" : "Vendita"}</span>
      <span class="pprice">${esc(price(r.price, r.listing_type))}</span><span class="pmeta">${r.surface_sqm ? esc(r.surface_sqm) + " m²" : ""}${r.rooms != null ? " · " + esc(r.rooms) + " locali" : ""}</span>
      <span class="powner">${esc(owners[r.id] || "")}</span>${r.status === "rejected" && r.rejection_reason ? `<span class="pnote">Motivo del rifiuto: ${esc(r.rejection_reason)}</span>` : ""}</span></button>`;
  }).join("");
}
export function dlg(inner) {
  const d = document.createElement("dialog"); d.className = "modal"; d.innerHTML = `<div class="modal-in">${inner}</div>`;
  document.body.append(d); d.addEventListener("close", () => d.remove());
  d.addEventListener("click", (e) => { if (e.target === d) d.close(); });
  d.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => d.close()));
  d.showModal(); return d;
}
export const fail = (d, msg) => { const n = $("#dErr", d); n.textContent = msg; n.hidden = false; n.scrollIntoView({ block: "nearest" }); };

export async function openDetail(ctx, id, onChange) {
  const { sb, user, profile } = ctx, admin = profile.role === "admin";
  const { data: p } = await sb.from("properties").select("*,property_photos(id,storage_path,position)").eq("id", id).maybeSingle();
  if (!p) return toast("Annuncio non disponibile.");
  const mine = p.submitted_by === user.id, own = mine || admin;
  const [{ data: priv }, urls, owners] = await Promise.all([sb.from("property_private").select("address").eq("property_id", id).maybeSingle(), signed(sb, p.property_photos.map((x) => x.storage_path)), ownerLabels(ctx, [p])]);
  const photos = [...p.property_photos].sort((a, b) => a.position - b.position);
  const editable = admin || (mine && ["draft", "rejected"].includes(p.status));
  const A = [];
  if (editable) A.push(["edit", "Modifica", "btn-ghost"]);
  if (own && ["draft", "rejected"].includes(p.status)) A.push(["submit", "Invia alla revisione", "btn-primary"]);
  if (mine && p.status === "submitted") A.push(["withdraw", "Ritira l'invio", "btn-ghost"]);
  if (admin && p.status === "submitted") A.push(["review", "Prendi in carico", "btn-ghost"]);
  if (admin && ["submitted", "in_review"].includes(p.status)) A.push(["approve", "Approva", "btn-primary"], ["reject", "Rifiuta…", "btn-ghost"]);
  if (own && p.status === "approved") A.push(["archive", "Archivia", "btn-ghost"]);
  if (admin || (mine && ["draft", "rejected"].includes(p.status))) A.push(["delete", "Elimina", "btn-danger"]);
  const row = (k, v) => (v == null || v === "" ? "" : `<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`);
  const d = dlg(`<div class="modal-head"><div><p class="eyebrow">${esc(owners[p.id] || "")}</p><h2>${esc(p.title)}</h2><p class="pmeta">${esc(p.municipality)} · ${esc(p.category)} · ${p.listing_type === "rent" ? "Affitto" : "Vendita"}</p></div><button class="btn btn-ghost" data-close aria-label="Chiudi">✕</button></div>
    ${own ? `<p>${badge(p.status)}</p>` : ""}
    ${p.status === "rejected" && own ? `<div class="notice error"><b>Annuncio rifiutato.</b> ${esc(p.rejection_reason || "")}</div>` : ""}
    <div class="gallery">${photos.map((x, i) => (urls[x.storage_path] ? `<img src="${esc(urls[x.storage_path])}" alt="Fotografia ${i + 1} di ${photos.length}" loading="lazy">` : "")).join("") || '<p class="pmeta">Nessuna fotografia caricata.</p>'}</div>
    <p class="pprice big">${esc(price(p.price, p.listing_type))}</p>
    <dl class="facts">${row("Superficie", p.surface_sqm && p.surface_sqm + " m²")}${row("Locali", p.rooms)}${row("Classe energetica", p.energy_class)}${row("Spese condominiali", p.condo_fees != null && eur.format(p.condo_fees) + " al mese")}${row("Riscaldamento", p.heating)}${row("Box", yn(p.has_garage))}${row("Cantina", yn(p.has_cellar))}${row("Indirizzo (riservato)", priv?.address)}</dl>
    ${p.description ? `<p class="desc">${esc(p.description)}</p>` : ""}
    <div id="rejectBox" hidden><div class="field"><label for="reason">Motivazione del rifiuto (visibile al professionista)</label><textarea id="reason" rows="3" maxlength="1000"></textarea></div><button class="btn btn-primary" data-act="reject-ok">Conferma il rifiuto</button></div>
    <div id="dErr" class="notice error" role="alert" hidden></div>
    <div class="actions">${A.map(([a, l, c]) => `<button class="btn ${c}" data-act="${a}">${l}</button>`).join("")}</div>`);
  const setStatus = async (status, extra, msg) => {
    const { error } = await sb.from("properties").update({ status, ...extra }).eq("id", id);
    if (error) return fail(d, error.message);
    d.close(); toast(msg); onChange && onChange();
  };
  d.addEventListener("click", async (e) => {
    const a = e.target.closest("[data-act]")?.dataset.act; if (!a) return;
    if (a === "edit") { d.close(); openEditor(ctx, id, onChange); }
    else if (a === "submit") setStatus("submitted", {}, "Annuncio inviato alla revisione.");
    else if (a === "withdraw") setStatus("draft", {}, "Invio ritirato: l'annuncio è tornato in bozza.");
    else if (a === "review") setStatus("in_review", {}, "Annuncio preso in carico.");
    else if (a === "approve") setStatus("approved", {}, "Annuncio approvato e pubblicato nella rete.");
    else if (a === "archive") setStatus("archived", {}, "Annuncio archiviato.");
    else if (a === "reject") { $("#rejectBox", d).hidden = false; $("#reason", d).focus(); }
    else if (a === "reject-ok") { const r = $("#reason", d).value.trim(); if (r.length < 5) return fail(d, "Scrivi una motivazione (almeno 5 caratteri)."); setStatus("rejected", { rejection_reason: r }, "Annuncio rifiutato con motivazione."); }
    else if (a === "delete") {
      if (!confirm("Eliminare definitivamente questo annuncio e le sue fotografie?")) return;
      if (photos.length) await sb.storage.from(BUCKET).remove(photos.map((x) => x.storage_path));
      const { error } = await sb.from("properties").delete().eq("id", id);
      if (error) return fail(d, error.message); d.close(); toast("Annuncio eliminato."); onChange && onChange();
    }
  });
}

export async function openEditor(ctx, id, onChange) {
  const { sb, user } = ctx; let p = {}, addr = "";
  if (id) {
    const r = await sb.from("properties").select("*,property_photos(id,storage_path,position)").eq("id", id).maybeSingle();
    if (!r.data) return toast("Annuncio non disponibile."); p = r.data;
    addr = (await sb.from("property_private").select("address").eq("property_id", id).maybeSingle()).data?.address || "";
  }
  const existing = [...(p.property_photos || [])].sort((a, b) => a.position - b.position), removed = [], fresh = [];
  const urls = await signed(sb, existing.map((x) => x.storage_path));
  const sel = (n, list, v, blank) => `<select id="f_${n}" name="${n}">${blank ? '<option value="">—</option>' : ""}${list.map((o) => `<option ${o === v ? "selected" : ""}>${esc(o)}</option>`).join("")}</select>`;
  const num = (n, l, v, step = "any") => `<div class="field"><label for="f_${n}">${l}</label><input id="f_${n}" name="${n}" type="number" inputmode="decimal" min="0" step="${step}" value="${esc(v ?? "")}"></div>`;
  const d = dlg(`<div class="modal-head"><div><p class="eyebrow">Rete professionisti</p><h2>${id ? "Modifica immobile" : "Nuovo immobile"}</h2></div><button class="btn btn-ghost" data-close aria-label="Chiudi">✕</button></div>
   <div class="notice warn">La rete è anonima: non scrivere nomi, telefoni o email (tuoi o del proprietario) nel titolo o nella descrizione. L'indirizzo preciso resta visibile solo a te e a Rubino.</div>
   <form id="pf" novalidate><div class="fgrid">
    <div class="field wide"><label for="f_title">Titolo *</label><input id="f_title" name="title" maxlength="140" value="${esc(p.title || "")}" required></div>
    <div class="field"><label for="f_municipality">Comune / zona *</label><input id="f_municipality" name="municipality" maxlength="100" value="${esc(p.municipality || "")}" required></div>
    <div class="field"><label for="f_category">Categoria</label>${sel("category", CATS, p.category || "Residenziale")}</div>
    <div class="field"><label for="f_listing_type">Tipo di annuncio</label><select id="f_listing_type" name="listing_type"><option value="sale" ${p.listing_type !== "rent" ? "selected" : ""}>Vendita</option><option value="rent" ${p.listing_type === "rent" ? "selected" : ""}>Affitto</option></select></div>
    ${num("price", "Prezzo (€; per l'affitto, al mese)", p.price)}${num("surface_sqm", "Superficie (m²)", p.surface_sqm)}${num("rooms", "Locali", p.rooms, "1")}
    <div class="field"><label for="f_energy_class">Classe energetica</label>${sel("energy_class", ENERGY, p.energy_class, true)}</div>
    ${num("condo_fees", "Spese condominiali (€ al mese)", p.condo_fees)}
    <div class="field"><label for="f_heating">Riscaldamento</label>${sel("heating", HEAT, p.heating, true)}</div>
    <div class="field check"><label><input type="checkbox" name="has_garage" ${p.has_garage ? "checked" : ""}> Box</label><label><input type="checkbox" name="has_cellar" ${p.has_cellar ? "checked" : ""}> Cantina</label></div>
    <div class="field wide"><label for="f_address">Indirizzo preciso (riservato)</label><input id="f_address" name="address" maxlength="200" value="${esc(addr)}" autocomplete="off"></div>
    <div class="field wide"><label for="f_description">Descrizione</label><textarea id="f_description" name="description" rows="4" maxlength="4000">${esc(p.description || "")}</textarea></div>
    <div class="field wide"><label for="f_files">Fotografie (da ${MIN_PHOTOS} a ${MAX_PHOTOS}; JPG, PNG o WebP, fino a 5 MB ciascuna)</label><input id="f_files" type="file" accept="image/jpeg,image/png,image/webp" multiple><div id="thumbs" class="thumbs"></div></div>
   </div><div id="dErr" class="notice error" role="alert" hidden></div>
   <div class="actions"><button type="button" class="btn btn-ghost" data-close>Annulla</button><button type="submit" class="btn btn-primary" id="saveBtn">Salva</button></div></form>`);
  const thumbs = $("#thumbs", d);
  const drawThumbs = () => {
    const items = [...existing.filter((x) => !removed.includes(x)).map((x) => ({ k: "old", x, u: urls[x.storage_path] })), ...fresh.map((f) => ({ k: "new", x: f, u: f.preview }))];
    thumbs.innerHTML = items.map((it, i) => `<figure><img src="${esc(it.u || "")}" alt="Fotografia ${i + 1}"><button type="button" class="btn btn-ghost" data-rm="${it.k}:${i}" aria-label="Rimuovi la fotografia ${i + 1}">Rimuovi</button></figure>`).join("");
    thumbs._items = items;
  };
  drawThumbs();
  thumbs.addEventListener("click", (e) => {
    const b = e.target.closest("[data-rm]"); if (!b) return; const it = thumbs._items[Number(b.dataset.rm.split(":")[1])];
    if (it.k === "old") removed.push(it.x); else { URL.revokeObjectURL(it.x.preview); fresh.splice(fresh.indexOf(it.x), 1); } drawThumbs();
  });
  $("#f_files", d).addEventListener("change", (e) => {
    $("#dErr", d).hidden = true;
    for (const f of e.target.files) {
      const total = existing.length - removed.length + fresh.length;
      if (!EXT[f.type]) { fail(d, `«${f.name}»: formato non ammesso (solo JPG, PNG o WebP).`); continue; }
      if (f.size > MAX_BYTES) { fail(d, `«${f.name}»: supera i 5 MB.`); continue; }
      if (total >= MAX_PHOTOS) { fail(d, `Massimo ${MAX_PHOTOS} fotografie.`); break; }
      f.preview = URL.createObjectURL(f); fresh.push(f);
    }
    e.target.value = ""; drawThumbs();
  });
  $("#pf", d).addEventListener("submit", async (e) => {
    e.preventDefault(); $("#dErr", d).hidden = true; const fd = new FormData(e.target), g = (n) => String(fd.get(n) || "").trim();
    const n = (k) => { const v = g(k).replace(",", "."); return v === "" ? null : Number(v); };
    const row = { title: g("title"), municipality: g("municipality"), category: g("category"), listing_type: g("listing_type"), description: g("description") || null,
      price: n("price"), surface_sqm: n("surface_sqm"), rooms: n("rooms"), energy_class: g("energy_class") || null, condo_fees: n("condo_fees"), heating: g("heating") || null, has_garage: fd.has("has_garage"), has_cellar: fd.has("has_cellar") };
    if (row.title.length < 3) return fail(d, "Inserisci un titolo (almeno 3 caratteri).");
    if (row.municipality.length < 2) return fail(d, "Inserisci il comune o la zona.");
    for (const k of ["price", "surface_sqm", "rooms", "condo_fees"]) if (row[k] != null && (!Number.isFinite(row[k]) || row[k] < 0)) return fail(d, "I valori numerici devono essere zero o positivi.");
    if (row.surface_sqm === 0) return fail(d, "La superficie deve essere maggiore di zero.");
    const btn = $("#saveBtn", d); btn.disabled = true; btn.textContent = "Salvataggio…";
    const stop = (m) => { btn.disabled = false; btn.textContent = "Salva"; fail(d, m); };
    let pid = id;
    if (id) { const { error } = await sb.from("properties").update(row).eq("id", id); if (error) return stop(error.message); }
    else { const { data, error } = await sb.from("properties").insert({ ...row, submitted_by: user.id, status: "draft" }).select("id").single(); if (error) return stop(error.message); pid = data.id; }
    const address = g("address");
    if (address || id) { const { error } = await sb.from("property_private").upsert({ property_id: pid, address: address || null }, { onConflict: "property_id" }); if (error) return stop(error.message); }
    for (const ph of removed) { await sb.from("property_photos").delete().eq("id", ph.id); await sb.storage.from(BUCKET).remove([ph.storage_path]); }
    let pos = existing.reduce((m, x) => Math.max(m, x.position + 1), 0), failed = 0;
    for (const f of fresh) {
      const path = `${pid}/${crypto.randomUUID()}.${EXT[f.type]}`;
      const up = await sb.storage.from(BUCKET).upload(path, f, { contentType: f.type, upsert: false });
      if (up.error) { failed++; continue; }
      const { error } = await sb.from("property_photos").insert({ property_id: pid, storage_path: path, position: pos++ });
      if (error) { await sb.storage.from(BUCKET).remove([path]); failed++; }
    }
    d.close(); onChange && onChange();
    toast(failed ? `Salvato, ma ${failed} fotografie non sono state caricate.` : id ? "Modifiche salvate." : `Bozza salvata. Aggiungi almeno ${MIN_PHOTOS} fotografie e invia alla revisione.`);
  });
}
