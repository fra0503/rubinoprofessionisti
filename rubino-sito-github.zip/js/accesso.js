import { $, configured, getClient, safeNext } from "./core.js?v=4";
const msg = $("#msg"), params = new URLSearchParams(location.search);
const show = (text, kind = "error") => { msg.className = "notice " + kind; msg.textContent = text; msg.hidden = false; };
const busy = (btn, on, label) => { btn.disabled = on; btn.textContent = on ? "Attendere…" : label; };
const login = $("#loginForm"), reset = $("#resetForm");
const swap = (toReset) => { login.hidden = toReset; reset.hidden = !toReset; msg.hidden = true; $("#title").textContent = toReset ? "Recupera l'accesso" : "Accedi alla rete"; $("#lead").textContent = toReset ? "Ti invieremo un link per scegliere una nuova password." : "Inserisci le credenziali del tuo account Rubino."; (toReset ? $("#resetEmail") : $("#email")).focus(); };
$("#forgotBtn").addEventListener("click", () => { $("#resetEmail").value = $("#email").value; swap(true); });
$("#backBtn").addEventListener("click", () => swap(false));

if (params.get("err") === "inactive") show("Questo account non è attivo. Contatta Rubino Immobiliare.");
if (params.get("ok") === "password") show("Password aggiornata. Ora puoi accedere.", "ok");
if (!configured || params.get("err") === "config") {
  show("Accesso non ancora attivo: collegamento a Supabase non configurato (vedi config.js e docs/SETUP.md).", "warn");
  for (const b of document.querySelectorAll("form button[type=submit]")) b.disabled = true;
} else {
  const sb = await getClient();
  const { data: { session } } = await sb.auth.getSession();
  if (session) location.replace(safeNext(params.get("next")));

  login.addEventListener("submit", async (e) => {
    e.preventDefault(); msg.hidden = true;
    const email = $("#email").value.trim(), password = $("#password").value;
    if (!email || !password) return show("Inserisci email e password.");
    const btn = $("#loginBtn"); busy(btn, true, "Accedi");
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error || !data.session) { busy(btn, false, "Accedi"); return show(/invalid|credentials/i.test(error?.message || "") ? "Email o password non corretti." : "Accesso non riuscito. Riprova tra poco."); }
    const { data: p } = await sb.from("profiles").select("active").eq("id", data.user.id).maybeSingle();
    if (!p || !p.active) { await sb.auth.signOut(); busy(btn, false, "Accedi"); return show("Questo account non è attivo. Contatta Rubino Immobiliare."); }
    location.replace(safeNext(params.get("next")));
  });

  reset.addEventListener("submit", async (e) => {
    e.preventDefault(); const email = $("#resetEmail").value.trim();
    if (!email) return show("Inserisci l'email dell'account.");
    const btn = $("#resetBtn"); busy(btn, true, "Invia il link di recupero");
    await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + "/reimposta-password" });
    busy(btn, false, "Invia il link di recupero");
    show("Se l'indirizzo è registrato, riceverai a breve un'email con il link di recupero.", "ok"); // stessa risposta sempre: nessuna enumerazione degli account
  });
}
