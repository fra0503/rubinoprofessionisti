import { $, esc, renderHeader, requireSession } from "./core.js?v=4";
import { STATUS, cardsHtml, firstPaths, openDetail, openEditor, ownerLabels, signed } from "./property-ui.js?v=4";
const ctx = await requireSession();
if (ctx) {
  renderHeader("immobili", ctx.profile, ctx.sb);
  const admin = ctx.profile.role === "admin", PAGE = 12, S = { page: 0, scope: admin ? "all" : "approved", q: "" };
  const scopes = admin ? [["all", "Tutti gli annunci"], ...Object.entries(STATUS).map(([k, v]) => [k, v])] : [["approved", "Annunci della rete"], ["mine", "I miei annunci"]];
  $("#scope").innerHTML = scopes.map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join("");
  $("#sub").textContent = admin ? "Tutti gli annunci della rete, con i dati reali dei professionisti." : "Gli annunci approvati della rete e i tuoi. I professionisti compaiono solo con un codice anonimo.";
  const list = $("#list");
  async function load() {
    list.innerHTML = '<p class="state">Caricamento…</p>';
    let q = ctx.sb.from("properties").select("id,title,municipality,category,listing_type,price,surface_sqm,rooms,status,submitted_by,rejection_reason,created_at,property_photos(storage_path,position)", { count: "exact" });
    if (S.scope === "mine") q = q.eq("submitted_by", ctx.user.id); else if (STATUS[S.scope] || S.scope === "approved") q = q.eq("status", S.scope);
    const s = S.q.replace(/[,%()*\\]/g, " ").trim(); if (s) q = q.or(`title.ilike.%${s}%,municipality.ilike.%${s}%`);
    const { data, count, error } = await q.order("created_at", { ascending: false }).range(S.page * PAGE, S.page * PAGE + PAGE - 1);
    if (error) { list.innerHTML = `<p class="state err">Impossibile caricare gli annunci. Riprova tra poco.</p>`; return; }
    if (!data.length) {
      list.innerHTML = `<div class="state"><p>${S.q ? "Nessun annuncio corrisponde alla ricerca." : S.scope === "mine" ? "Non hai ancora inserito annunci." : "Non ci sono ancora annunci."}</p>${S.scope === "mine" || !S.q ? '<button class="btn btn-primary" data-new>Inserisci un immobile</button>' : ""}</div>`; $("#pager").hidden = true; return;
    }
    const [urls, owners] = await Promise.all([signed(ctx.sb, firstPaths(data)), ownerLabels(ctx, data)]);
    list.innerHTML = `<div class="pgrid">${cardsHtml(data, urls, owners, ctx)}</div>`;
    const pages = Math.max(1, Math.ceil(count / PAGE)); $("#pager").hidden = pages < 2;
    $("#pinfo").textContent = `Pagina ${S.page + 1} di ${pages} · ${count} annunci`; $("#prev").disabled = S.page === 0; $("#next").disabled = S.page >= pages - 1;
  }
  list.addEventListener("click", (e) => { if (e.target.closest("[data-new]")) return openEditor(ctx, null, load); const c = e.target.closest(".pcard"); if (c) openDetail(ctx, c.dataset.id, load); });
  $("#newBtn").addEventListener("click", () => openEditor(ctx, null, load));
  $("#scope").addEventListener("change", (e) => { S.scope = e.target.value; S.page = 0; load(); });
  let t; $("#search").addEventListener("input", (e) => { clearTimeout(t); t = setTimeout(() => { S.q = e.target.value; S.page = 0; load(); }, 300); });
  $("#prev").addEventListener("click", () => { S.page--; load(); scrollTo(0, 0); }); $("#next").addEventListener("click", () => { S.page++; load(); scrollTo(0, 0); });
  await load();
  const open = new URLSearchParams(location.search).get("open"); if (open) openDetail(ctx, open, load);
}
