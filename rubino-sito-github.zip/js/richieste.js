import { $, esc, renderHeader, requireSession } from "./core.js?v=4";
import { RSTATUS, openRequest, openRequestEditor, requestCards, requestOwners } from "./request-ui.js?v=4";
const ctx = await requireSession();
if (ctx) {
  renderHeader("richieste", ctx.profile, ctx.sb);
  const admin = ctx.profile.role === "admin", PAGE = 12, S = { page: 0, scope: "all", need: "", q: "" }, list = $("#list");
  const scopes = [["all", "Tutte le richieste"], ...(admin ? Object.entries(RSTATUS) : [["mine", "Le mie richieste"]])];
  $("#scope").innerHTML = scopes.map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join("");
  $("#sub").textContent = admin ? "Tutte le richieste della rete, con i dati reali dei professionisti." : "Le richieste di ricerca della rete. I professionisti compaiono solo con un codice anonimo e non si registrano dati dei clienti.";
  async function load() {
    list.innerHTML = '<p class="state">Caricamento…</p>';
    let q = ctx.sb.from("client_requests").select("id,title,municipality,need,category,budget_min,budget_max,surface_min,surface_max,status,submitted_by,created_at", { count: "exact" });
    if (S.scope === "mine") q = q.eq("submitted_by", ctx.user.id); else if (RSTATUS[S.scope]) q = q.eq("status", S.scope);
    if (S.need) q = q.eq("need", S.need);
    const s = S.q.replace(/[,%()*\\]/g, " ").trim(); if (s) q = q.or(`title.ilike.%${s}%,municipality.ilike.%${s}%`);
    const { data, count, error } = await q.order("created_at", { ascending: false }).range(S.page * PAGE, S.page * PAGE + PAGE - 1);
    if (error) { list.innerHTML = '<p class="state err">Impossibile caricare le richieste. Riprova tra poco.</p>'; return; }
    if (!data.length) { list.innerHTML = `<div class="state"><p>${S.q || S.need ? "Nessuna richiesta corrisponde alla ricerca." : "Non ci sono ancora richieste."}</p><button class="btn btn-primary" data-new>Registra una richiesta</button></div>`; $("#pager").hidden = true; return; }
    list.innerHTML = `<div class="pgrid">${requestCards(data, await requestOwners(ctx, data))}</div>`;
    const pages = Math.max(1, Math.ceil(count / PAGE)); $("#pager").hidden = pages < 2; $("#pinfo").textContent = `Pagina ${S.page + 1} di ${pages} · ${count} richieste`; $("#prev").disabled = S.page === 0; $("#next").disabled = S.page >= pages - 1;
  }
  list.addEventListener("click", (e) => { if (e.target.closest("[data-new]")) return openRequestEditor(ctx, null, load); const c = e.target.closest(".pcard"); if (c) openRequest(ctx, c.dataset.id, load); });
  $("#newBtn").addEventListener("click", () => openRequestEditor(ctx, null, load));
  $("#scope").addEventListener("change", (e) => { S.scope = e.target.value; S.page = 0; load(); });
  $("#need").addEventListener("change", (e) => { S.need = e.target.value; S.page = 0; load(); });
  let t; $("#search").addEventListener("input", (e) => { clearTimeout(t); t = setTimeout(() => { S.q = e.target.value; S.page = 0; load(); }, 300); });
  $("#prev").addEventListener("click", () => { S.page--; load(); scrollTo(0, 0); }); $("#next").addEventListener("click", () => { S.page++; load(); scrollTo(0, 0); });
  await load();
}
