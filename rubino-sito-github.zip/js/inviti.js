// Inviti riservati (solo amministratore). Il link è mostrato UNA volta alla creazione: sul database resta solo l'hash.
import { $, esc, fmtDate, fn, renderHeader, requireSession, toast } from "./core.js?v=4";
import { dlg, fail } from "./property-ui.js?v=4";
const ctx = await requireSession();
if (ctx && ctx.profile.role !== "admin") location.replace("/panoramica");
else if (ctx) {
  renderHeader("inviti", ctx.profile, ctx.sb);
  const PROF = ["Geometra", "Amministratore di condominio", "Tecnico", "Artigiano", "Notaio", "Avvocato", "Architetto", "Ingegnere", "Altro"], PAGE = 15, S = { page: 0, f: "" }, list = $("#list");
  $("#i_prof").innerHTML = '<option value="">—</option>' + PROF.map((p) => `<option>${esc(p)}</option>`).join("");
  const state = (i) => (i.status === "accepted" ? ["Accettato", "approved"] : i.status === "revoked" ? ["Revocato", "rejected"] : new Date(i.expires_at) < new Date() ? ["Scaduto", "rejected"] : ["In attesa", "submitted"]);
  async function load() {
    list.innerHTML = '<p class="state">Caricamento…</p>';
    let q = ctx.sb.from("invites").select("id,email,full_name,profession,notes,status,expires_at,email_sent_at,accepted_at,created_at", { count: "exact" }); // niente token_hash: non è leggibile
    if (S.f === "pending") q = q.eq("status", "pending"); else if (S.f) q = q.eq("status", S.f);
    const { data, count, error } = await q.order("created_at", { ascending: false }).range(S.page * PAGE, S.page * PAGE + PAGE - 1);
    if (error) { list.innerHTML = '<p class="state err">Impossibile caricare gli inviti. Riprova tra poco.</p>'; return; }
    if (!data.length) { list.innerHTML = '<div class="state"><p>Nessun invito. Compila il modulo qui sopra per invitare un professionista.</p></div>'; $("#pager").hidden = true; return; }
    list.innerHTML = data.map((i) => { const [lab, cls] = state(i), usable = i.status !== "accepted";
      return `<article class="irow" data-id="${esc(i.id)}"><div><b>${esc(i.full_name)}</b> <span class="badge b-${cls}">${lab}</span><p class="pmeta">${esc(i.email)}${i.profession ? " · " + esc(i.profession) : ""}</p>
      <p class="pmeta">Creato ${esc(fmtDate(i.created_at))} · ${i.status === "accepted" ? "attivato " + esc(fmtDate(i.accepted_at)) : "scade " + esc(fmtDate(i.expires_at))} · ${i.email_sent_at ? "email inviata" : "link da condividere a mano"}</p>${i.notes ? `<p class="pmeta">Note: ${esc(i.notes)}</p>` : ""}</div>
      <div class="actions">${i.status === "pending" && lab === "In attesa" ? '<button class="btn btn-ghost" data-a="revoke">Revoca</button>' : ""}${usable ? '<button class="btn btn-ghost" data-a="regenerate">Rigenera il link</button>' : ""}</div></article>`; }).join("");
    const pages = Math.max(1, Math.ceil(count / PAGE)); $("#pager").hidden = pages < 2; $("#pinfo").textContent = `Pagina ${S.page + 1} di ${pages} · ${count} inviti`; $("#prev").disabled = S.page === 0; $("#next").disabled = S.page >= pages - 1;
  }
  function showLink(r, name, email) {
    const url = r.invite_url, msg = `Ciao ${name}, ti invito alla rete professionisti di Rubino Immobiliare. Attiva il tuo account da qui (link personale, valido una volta sola): ${url}`;
    const d = dlg(`<div class="modal-head"><div><p class="eyebrow">Invito creato</p><h2>Link di attivazione</h2></div><button class="btn btn-ghost" data-close aria-label="Chiudi">✕</button></div>
      ${r.email_sent ? `<div class="notice ok">Email inviata a ${esc(email)}.</div>` : `<div class="notice warn"><b>L'email NON è stata inviata.</b> Copia il link e invialo tu${r.email_provider_configured ? "" : " (per l'invio automatico serve configurare un servizio email, vedi guida)"}.</div>`}
      <div class="field"><label for="lk">Link personale (si vede solo adesso: poi potrai solo rigenerarlo)</label><input id="lk" readonly value="${esc(url)}"></div>
      <p class="pmeta">Scade il ${esc(fmtDate(r.expires_at))}. Vale per una sola attivazione.</p>
      <div class="actions"><button class="btn btn-primary" data-a="copy">Copia il link</button><a class="btn btn-ghost" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(msg)}">Apri WhatsApp</a>
      <a class="btn btn-ghost" href="mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent("Invito alla rete professionisti Rubino Immobiliare")}&body=${encodeURIComponent(msg)}">Apri email</a></div><p class="pmeta">WhatsApp ed email si aprono con un messaggio già scritto: l'invio lo confermi tu.</p>`);
    $("[data-a=copy]", d).addEventListener("click", async () => { try { await navigator.clipboard.writeText(url); toast("Link copiato."); } catch { const i = $("#lk", d); i.select(); toast("Seleziona il link e copialo."); } });
  }
  $("#iform").addEventListener("submit", async (e) => {
    e.preventDefault(); const n = $("#i_name").value.trim(), em = $("#i_email").value.trim().toLowerCase(), err = $("#iErr"); err.hidden = true;
    const bad = (m) => { err.textContent = m; err.hidden = false; };
    if (n.length < 2) return bad("Inserisci il nome e cognome."); if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em)) return bad("Inserisci un indirizzo email valido.");
    const btn = $("#iBtn"); btn.disabled = true; btn.textContent = "Creazione…";
    const r = await fn(ctx.sb, "create-invite", { action: "create", full_name: n, email: em, profession: $("#i_prof").value, notes: $("#i_notes").value.trim(), send_email: $("#i_send").checked });
    btn.disabled = false; btn.textContent = "Crea invito"; if (!r.ok) return bad(r.data?.error || "Impossibile creare l'invito.");
    $("#iform").reset(); showLink(r.data, n, em); load();
  });
  list.addEventListener("click", async (e) => {
    const a = e.target.closest("[data-a]")?.dataset.a; if (!a) return; const row = e.target.closest(".irow"), id = row.dataset.id;
    if (a === "revoke") { if (!confirm("Revocare questo invito? Il link smetterà di funzionare.")) return; const r = await fn(ctx.sb, "create-invite", { action: "revoke", invite_id: id }); toast(r.ok ? "Invito revocato." : r.data?.error || "Operazione non riuscita."); load(); }
    else { const r = await fn(ctx.sb, "create-invite", { action: "regenerate", invite_id: id, send_email: false }); if (!r.ok) return toast(r.data?.error || "Operazione non riuscita."); const nm = row.querySelector("b").textContent, em = row.querySelector(".pmeta").textContent.split(" · ")[0]; showLink(r.data, nm, em); load(); }
  });
  $("#filter").addEventListener("change", (e) => { S.f = e.target.value; S.page = 0; load(); });
  $("#prev").addEventListener("click", () => { S.page--; load(); }); $("#next").addEventListener("click", () => { S.page++; load(); });
  await load();
}
