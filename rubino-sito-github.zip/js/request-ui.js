// Interfaccia condivisa per le richieste di ricerca. Nessun dato identificativo del cliente.
import { $, esc, toast } from "./core.js?v=4";
import { dlg, fail } from "./property-ui.js?v=4";
export const RSTATUS = { new: "Nuova", matching: "In ricerca", matched: "Abbinata", closed: "Chiusa", archived: "Archiviata" };
const CATS = ["Residenziale", "Commerciale", "Terreno", "Altro"], EMP = ["Indeterminato", "Determinato", "Autonomo", "Pensionato", "Altro"];
const E = new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR", maximumFractionDigits: 0 });
export const money = (a, b) => (a == null && b == null ? "Budget non indicato" : a != null && b != null ? `${E.format(a)} – ${E.format(b)}` : a != null ? `da ${E.format(a)}` : `fino a ${E.format(b)}`);
const range = (a, b, u) => (a == null && b == null ? "" : a != null && b != null ? `${a} – ${b} ${u}` : a != null ? `da ${a} ${u}` : `fino a ${b} ${u}`);
// Stesso criterio del database: email e numeri di telefono non sono ammessi nei testi liberi
export const hasPersonalData = (t) => /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i.test(t) || /\+\d{1,3}[\s.-]?\d{6,}|\b3\d{2}[\s.-]?\d{6,7}\b|\b0\d{1,3}[\s./-]?\d{5,8}\b|\d{9,}/.test(t);
const sb2 = (v) => (v === true ? "Sì" : v === false ? "No" : "");

export async function requestOwners(ctx, rows) {
  const out = {}, ids = rows.map((r) => r.id); if (!ids.length) return out;
  const { data: al } = await ctx.sb.from("request_owner_alias").select("request_id,alias_code").in("request_id", ids);
  (al || []).forEach((a) => (out[a.request_id] = `Professionista ${a.alias_code}`));
  if (ctx.profile.role === "admin") {
    const { data: pr } = await ctx.sb.from("profiles").select("id,full_name,alias_code").in("id", [...new Set(rows.map((r) => r.submitted_by))]);
    const nm = {}; (pr || []).forEach((p) => (nm[p.id] = `${p.full_name} · ${p.alias_code}`));
    rows.forEach((r) => { if (nm[r.submitted_by]) out[r.id] = nm[r.submitted_by]; });
  }
  rows.forEach((r) => { if (r.submitted_by === ctx.user.id) out[r.id] = "Tu"; });
  return out;
}
export const requestCards = (rows, owners) => rows.map((r) => `<button class="pcard rcard" type="button" data-id="${esc(r.id)}"><span class="pbody">
  <span class="rtop"><span class="badge b-${r.need}">${r.need === "buy" ? "Acquisto" : "Affitto"}</span><span class="badge">${esc(RSTATUS[r.status] || r.status)}</span></span>
  <b class="ptitle">${esc(r.title)}</b><span class="pmeta">${esc(r.municipality)}${r.category ? " · " + esc(r.category) : ""}</span>
  <span class="pprice">${esc(money(r.budget_min, r.budget_max))}</span><span class="pmeta">${esc(range(r.surface_min, r.surface_max, "m²"))}</span><span class="powner">${esc(owners[r.id] || "")}</span></span></button>`).join("");

export async function openRequest(ctx, id, onChange) {
  const { sb, user, profile } = ctx;
  const { data: r } = await sb.from("client_requests").select("*").eq("id", id).maybeSingle();
  if (!r) return toast("Richiesta non disponibile.");
  const own = r.submitted_by === user.id || profile.role === "admin", owners = await requestOwners(ctx, [r]);
  const row = (k, v) => (v == null || v === "" ? "" : `<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`);
  const d = dlg(`<div class="modal-head"><div><p class="eyebrow">${esc(owners[r.id] || "")}</p><h2>${esc(r.title)}</h2><p class="pmeta">${esc(r.municipality)} · ${r.need === "buy" ? "Acquisto" : "Affitto"}</p></div><button class="btn btn-ghost" data-close aria-label="Chiudi">✕</button></div>
   <p class="pprice big">${esc(money(r.budget_min, r.budget_max))}</p>
   <dl class="facts">${row("Categoria", r.category)}${row("Superficie", range(r.surface_min, r.surface_max, "m²"))}${row("Stato", RSTATUS[r.status])}${r.need === "buy" ? row("Mutuo", sb2(r.needs_mortgage)) : row("Situazione lavorativa", r.employment_type) + row("Garante", sb2(r.has_guarantor))}</dl>
   ${r.requirements ? `<p class="desc">${esc(r.requirements)}</p>` : ""}
   ${own ? `<div class="field"><label for="st">Stato della richiesta</label><select id="st">${Object.entries(RSTATUS).map(([k, v]) => `<option value="${k}" ${k === r.status ? "selected" : ""}>${v}</option>`).join("")}</select></div>` : ""}
   <div id="dErr" class="notice error" role="alert" hidden></div>
   <div class="actions">${own ? '<button class="btn btn-primary" data-act="save">Aggiorna stato</button><button class="btn btn-ghost" data-act="edit">Modifica</button><button class="btn btn-danger" data-act="delete">Elimina</button>' : ""}</div>`);
  d.addEventListener("click", async (e) => {
    const a = e.target.closest("[data-act]")?.dataset.act; if (!a) return;
    if (a === "edit") { d.close(); openRequestEditor(ctx, id, onChange); }
    else if (a === "save") { const { error } = await sb.from("client_requests").update({ status: $("#st", d).value }).eq("id", id); if (error) return fail(d, error.message); d.close(); toast("Stato aggiornato."); onChange && onChange(); }
    else if (a === "delete") { if (!confirm("Eliminare definitivamente questa richiesta?")) return; const { error } = await sb.from("client_requests").delete().eq("id", id); if (error) return fail(d, error.message); d.close(); toast("Richiesta eliminata."); onChange && onChange(); }
  });
}

export async function openRequestEditor(ctx, id, onChange) {
  const { sb, user } = ctx; let r = {};
  if (id) { const x = await sb.from("client_requests").select("*").eq("id", id).maybeSingle(); if (!x.data) return toast("Richiesta non disponibile."); r = x.data; }
  const yn = (v) => (v === true ? "yes" : v === false ? "no" : "");
  const num = (n, l, v) => `<div class="field"><label for="f_${n}">${l}</label><input id="f_${n}" name="${n}" type="number" inputmode="decimal" min="0" step="any" value="${esc(v ?? "")}"></div>`;
  const ynSel = (n, l, v) => `<div class="field"><label for="f_${n}">${l}</label><select id="f_${n}" name="${n}"><option value="">Non indicato</option><option value="yes" ${yn(v) === "yes" ? "selected" : ""}>Sì</option><option value="no" ${yn(v) === "no" ? "selected" : ""}>No</option></select></div>`;
  const d = dlg(`<div class="modal-head"><div><p class="eyebrow">Rete professionisti</p><h2>${id ? "Modifica richiesta" : "Nuova richiesta"}</h2></div><button class="btn btn-ghost" data-close aria-label="Chiudi">✕</button></div>
   <div class="notice warn"><b>Nessun dato del cliente.</b> Non scrivere nomi, telefoni, email o altri dati che permettano di riconoscerlo: descrivi solo l'esigenza di ricerca.</div>
   <form id="rf" novalidate><div class="fgrid">
    <div class="field wide"><label for="f_title">Titolo *</label><input id="f_title" name="title" maxlength="140" value="${esc(r.title || "")}" required></div>
    <div class="field"><label for="f_municipality">Comune / zona *</label><input id="f_municipality" name="municipality" maxlength="100" value="${esc(r.municipality || "")}" required></div>
    <div class="field"><label for="f_need">Esigenza</label><select id="f_need" name="need"><option value="buy" ${r.need !== "rent" ? "selected" : ""}>Acquisto</option><option value="rent" ${r.need === "rent" ? "selected" : ""}>Affitto</option></select></div>
    <div class="field"><label for="f_category">Categoria</label><select id="f_category" name="category"><option value="">Qualsiasi</option>${CATS.map((c) => `<option ${c === r.category ? "selected" : ""}>${c}</option>`).join("")}</select></div>
    <span></span>${num("budget_min", "Budget minimo (€)", r.budget_min)}${num("budget_max", "Budget massimo (€)", r.budget_max)}${num("surface_min", "Superficie minima (m²)", r.surface_min)}${num("surface_max", "Superficie massima (m²)", r.surface_max)}
    <div id="buyBox" ${r.need === "rent" ? "hidden" : ""}>${ynSel("needs_mortgage", "Serve un mutuo?", r.needs_mortgage)}</div>
    <div id="rentBox" class="fgrid sub2" ${r.need === "rent" ? "" : "hidden"}><div class="field"><label for="f_employment_type">Situazione lavorativa</label><select id="f_employment_type" name="employment_type"><option value="">Non indicata</option>${EMP.map((c) => `<option ${c === r.employment_type ? "selected" : ""}>${c}</option>`).join("")}</select></div>${ynSel("has_guarantor", "È presente un garante?", r.has_guarantor)}</div>
    <div class="field wide"><label for="f_requirements">Requisiti (piano, box, terrazzo, ecc.)</label><textarea id="f_requirements" name="requirements" rows="4" maxlength="2000">${esc(r.requirements || "")}</textarea></div>
   </div><div id="dErr" class="notice error" role="alert" hidden></div>
   <div class="actions"><button type="button" class="btn btn-ghost" data-close>Annulla</button><button type="submit" class="btn btn-primary" id="saveBtn">Salva</button></div></form>`);
  $("#f_need", d).addEventListener("change", (e) => { $("#buyBox", d).hidden = e.target.value === "rent"; $("#rentBox", d).hidden = e.target.value !== "rent"; });
  $("#rf", d).addEventListener("submit", async (e) => {
    e.preventDefault(); $("#dErr", d).hidden = true; const fd = new FormData(e.target), g = (k) => String(fd.get(k) || "").trim(), n = (k) => { const v = g(k).replace(",", "."); return v === "" ? null : Number(v); };
    const tri = (k) => (g(k) === "yes" ? true : g(k) === "no" ? false : null), need = g("need");
    const row = { title: g("title"), municipality: g("municipality"), need, category: g("category") || null, budget_min: n("budget_min"), budget_max: n("budget_max"), surface_min: n("surface_min"), surface_max: n("surface_max"),
      requirements: g("requirements") || null, needs_mortgage: need === "buy" ? tri("needs_mortgage") : null, employment_type: need === "rent" ? g("employment_type") || null : null, has_guarantor: need === "rent" ? tri("has_guarantor") : null };
    if (row.title.length < 3) return fail(d, "Inserisci un titolo (almeno 3 caratteri).");
    if (row.municipality.length < 2) return fail(d, "Inserisci il comune o la zona.");
    if (hasPersonalData(row.title) || hasPersonalData(row.requirements || "")) return fail(d, "Il testo sembra contenere un'email o un numero di telefono: rimuovilo. Le richieste non devono contenere dati del cliente.");
    for (const k of ["budget_min", "budget_max", "surface_min", "surface_max"]) if (row[k] != null && (!Number.isFinite(row[k]) || row[k] < 0)) return fail(d, "I valori numerici devono essere zero o positivi.");
    if (row.budget_min != null && row.budget_max != null && row.budget_min > row.budget_max) return fail(d, "Il budget minimo non può superare il massimo.");
    if (row.surface_min != null && row.surface_max != null && row.surface_min > row.surface_max) return fail(d, "La superficie minima non può superare la massima.");
    const btn = $("#saveBtn", d); btn.disabled = true; btn.textContent = "Salvataggio…";
    const { error } = id ? await sb.from("client_requests").update(row).eq("id", id) : await sb.from("client_requests").insert({ ...row, submitted_by: user.id, status: "new" });
    if (error) { btn.disabled = false; btn.textContent = "Salva"; return fail(d, error.message); }
    d.close(); toast(id ? "Richiesta aggiornata." : "Richiesta salvata."); onChange && onChange();
  });
}
