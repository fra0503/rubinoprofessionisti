import { $, callFunction, configured } from "./core.js?v=4";
const msg = $("#msg"), form = $("#form"), lead = $("#lead");
const show = (t, k = "error") => { msg.className = "notice " + k; msg.textContent = t; msg.hidden = false; };
const token = new URLSearchParams(location.search).get("token") || "";
history.replaceState(null, "", location.pathname); // il token non resta nella barra degli indirizzi
const bad = () => { lead.textContent = "Il link non è utilizzabile."; show("Link non valido, scaduto o già utilizzato. Chiedi a Rubino Immobiliare un nuovo invito."); };
if (!configured) { lead.textContent = ""; show("Attivazione non ancora disponibile: collegamento a Supabase non configurato.", "warn"); }
else if (!/^[0-9a-f]{64}$/.test(token)) bad();
else {
  const v = await callFunction("accept-invite", { action: "validate", token });
  if (!v.ok) { v.data?.error?.includes("Troppi") ? (lead.textContent = "", show(v.data.error)) : bad(); }
  else {
    lead.textContent = "Scegli la password per completare l'attivazione.";
    $("#name").value = v.data.full_name; $("#email").value = v.data.email; form.hidden = false; $("#pw").focus();
    form.addEventListener("submit", async (e) => {
      e.preventDefault(); msg.hidden = true;
      const pw = $("#pw").value;
      if (pw.length < 10) return show("La password deve avere almeno 10 caratteri.");
      if (pw !== $("#pw2").value) return show("Le due password non coincidono.");
      const btn = $("#btn"); btn.disabled = true; btn.textContent = "Attendere…";
      const r = await callFunction("accept-invite", { action: "accept", token, password: pw });
      if (!r.ok) { btn.disabled = false; btn.textContent = "Attiva l'account"; return show(r.data?.error || "Attivazione non riuscita."); }
      form.hidden = true; lead.textContent = ""; show("Account attivato. Ora puoi accedere.", "ok"); $("#done").hidden = false;
    });
  }
}
