// Nucleo condiviso: client Supabase, guardia di sessione, intestazione/menu, utilità.
import { SUPABASE_URL, SUPABASE_ANON_KEY } from "../config.js";
export const configured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);
let client;
export async function getClient() {
  if (!configured) return null;
  if (!client) {
    const { createClient } = await import("https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm");
    client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
  }
  return client;
}
export const $ = (s, r = document) => r.querySelector(s);
export const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export function toast(msg) {
  let t = $("#toast"); if (!t) { t = document.createElement("div"); t.id = "toast"; t.setAttribute("role", "status"); document.body.append(t); }
  t.textContent = msg; t.classList.add("show"); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove("show"), 3600);
}
export const safeNext = (n) => (typeof n === "string" && /^\/[^/\\]/.test(n) ? n : "/panoramica");

// Sezioni. `ready` = pagina già consegnata: il menu mostra solo link che funzionano davvero.
export const SECTIONS = [
  { id: "panoramica", label: "Panoramica", href: "/panoramica", ready: true },
  { id: "immobili", label: "Immobili", href: "/immobili", ready: true },
  { id: "in-revisione", label: "In revisione", href: "/in-revisione", ready: true },
  { id: "richieste", label: "Richieste", href: "/richieste", ready: true },
  { id: "abbinamenti", label: "Abbinamenti", href: "/abbinamenti", admin: true, ready: true },
  { id: "professionisti", label: "Professionisti", href: "/professionisti", admin: true, ready: true },
  { id: "inviti", label: "Inviti", href: "/inviti", admin: true, ready: true },
  { id: "attivita", label: "Attività", href: "/attivita", admin: true, ready: true },
];

export async function requireSession() {
  const sb = await getClient();
  if (!sb) { location.replace("/accesso?err=config"); return null; }
  const { data: { session } } = await sb.auth.getSession();
  if (!session) { location.replace("/accesso?next=" + encodeURIComponent(location.pathname)); return null; }
  const { data: profile } = await sb.from("profiles").select("full_name,role,active").eq("id", session.user.id).maybeSingle();
  if (!profile || !profile.active) { await sb.auth.signOut(); location.replace("/accesso?err=inactive"); return null; }
  return { sb, user: session.user, profile };
}

export function renderHeader(active, profile, sb) {
  const items = SECTIONS.filter((s) => s.ready && (!s.admin || profile.role === "admin"));
  const initial = esc((profile.full_name || "R").trim()[0]?.toUpperCase());
  $("#siteHeader").innerHTML = `
    <a class="brand" href="/panoramica" aria-label="Rubino Immobiliare, Rete Professionisti">
      <span class="brand-mark" aria-hidden="true"></span>
      <span class="brand-text"><strong>RUBINO</strong><small>RETE PROFESSIONISTI</small></span></a>
    <button class="menu-btn" id="menuBtn" aria-expanded="false" aria-controls="navMenu" aria-label="Apri il menu"><span></span><span></span><span></span></button>
    <nav class="nav" id="navMenu" aria-label="Navigazione principale">
      ${items.map((s) => `<a href="${s.href}" ${s.id === active ? 'aria-current="page"' : ""}>${s.label}</a>`).join("")}
      <div class="nav-user"><span class="avatar" aria-hidden="true">${initial}</span>
        <span class="who"><strong>${esc(profile.full_name)}</strong><small>${profile.role === "admin" ? "Amministratore" : "Professionista"}</small></span>
        <button class="btn btn-ghost" id="logoutBtn" type="button">Esci</button></div>
    </nav>`;
  const btn = $("#menuBtn"), nav = $("#navMenu");
  const setOpen = (o) => { nav.classList.toggle("open", o); btn.setAttribute("aria-expanded", o); btn.setAttribute("aria-label", o ? "Chiudi il menu" : "Apri il menu"); document.body.classList.toggle("no-scroll", o && matchMedia("(max-width:1279px)").matches); };
  btn.addEventListener("click", () => setOpen(!nav.classList.contains("open")));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && nav.classList.contains("open")) { setOpen(false); btn.focus(); } });
  matchMedia("(min-width:1280px)").addEventListener("change", () => setOpen(false));
  $("#logoutBtn").addEventListener("click", async () => { await sb.auth.signOut(); location.replace("/accesso"); });
}

export async function callFunction(name, body, accessToken) {
  const res = await fetch(`${SUPABASE_URL}/functions/v1/${name}`, {
    method: "POST", headers: { "Content-Type": "application/json", apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${accessToken || SUPABASE_ANON_KEY}` },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, data };
}
// Chiamata a una Edge Function con la sessione dell'utente; errori di rete spiegati in modo comprensibile
export async function fn(sb, name, body) {
  try {
    const { data: { session } } = await sb.auth.getSession();
    return await callFunction(name, body, session?.access_token);
  } catch {
    return { ok: false, data: { error: "Servizio del server non raggiungibile. Le funzioni Supabase potrebbero non essere ancora attive, oppure APP_BASE_URL non coincide con l'indirizzo di questo sito." } };
  }
}
export function downloadFile(name, text, type) {
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name;
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
// CSV per Excel italiano (separatore «;», BOM UTF-8). Le celle che iniziano con = + - @ sono neutralizzate (formula injection).
const cell = (v) => { let s = v == null ? "" : String(v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
export const downloadCsv = (name, headers, rows) => downloadFile(name, "\ufeff" + [headers, ...rows].map((r) => r.map(cell).join(";")).join("\r\n"), "text/csv;charset=utf-8");
export const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString("it-IT", { dateStyle: "short", timeStyle: "short" }) : "");
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("/sw.js").catch(() => {});
