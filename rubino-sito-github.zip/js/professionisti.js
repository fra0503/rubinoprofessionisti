// Professionisti: gestione account (solo amministratore). Ruolo e stato passano dalla funzione server admin-users.
import { $, downloadCsv, downloadFile, esc, fmtDate, fn, renderHeader, requireSession, toast } from "./core.js?v=4";
import { dlg, fail } from "./property-ui.js?v=4";
const ctx = await requireSession();
if (ctx && ctx.profile.role !== "admin") location.replace("/panoramica");
else if (ctx) {
  renderHeader("professionisti", ctx.profile, ctx.sb);
  const PAGE = 12, S = { page: 0, scope: "all", q: "" }, list = $("#list"), COLS = "id,full_name,email,alias_code,profession,municipality,phone,role,active,created_at";
  const ROLE = { admin: "Amministratore", professional: "Professionista" };
  const filtered = (q) => { if (S.scope === "active") q = q.eq("active", true); else if (S.scope === "inactive") q = q.eq("active", false); else if (S.scope === "admin") q = q.eq("role", "admin");
    const s = S.q.replace(/[,%()*\\]/g, " ").trim(); return s ? q.or(`full_name.ilike.%${s}%,email.ilike.%${s}%,alias_code.ilike.%${s}%`) : q; };
  async function load() {
    list.innerHTML = '<p class="state">Caricamento…</p>';
    const { data, count, error } = await filtered(ctx.sb.from("profiles").select(COLS, { count: "exact" })).order("full_name", { ascending: true }).range(S.page * PAGE, S.page * PAGE + PAGE - 1);
    if (error) { list.innerHTML = '<p class="state err">Impossibile caricare i professionisti. Riprova tra poco.</p>'; return; }
    if (!data.length) { list.innerHTML = '<div class="state"><p>Nessun professionista corrisponde alla ricerca.</p></div>'; $("#pager").hidden = true; return; }
    list.innerHTML = `<div class="pgrid">${data.map((u) => `<button class="pcard rcard" type="button" data-id="${esc(u.id)}"><span class="pbody"><span class="rtop"><span class="badge">${ROLE[u.role]}</span><span class="badge ${u.active ? "b-approved" : "b-rejected"}">${u.active ? "Attivo" : "Disattivato"}</span></span>
      <b class="ptitle">${esc(u.full_name)}${u.id === ctx.user.id ? " (tu)" : ""}</b><span class="pmeta">${esc(u.email)}</span><span class="pmeta">${esc([u.profession, u.municipality].filter(Boolean).join(" · "))}</span><span class="powner">Codice anonimo ${esc(u.alias_code)}</span></span></button>`).join("")}</div>`;
    S.rows = data; const pages = Math.max(1, Math.ceil(count / PAGE)); $("#pager").hidden = pages < 2; $("#pinfo").textContent = `Pagina ${S.page + 1} di ${pages} · ${count} account`; $("#prev").disabled = S.page === 0; $("#next").disabled = S.page >= pages - 1;
  }
  function openUser(u) {
    const self = u.id === ctx.user.id;
    const d = dlg(`<div class="modal-head"><div><p class="eyebrow">Codice anonimo ${esc(u.alias_code)}</p><h2>${esc(u.full_name)}</h2><p class="pmeta">${esc(u.email)} · iscritto il ${esc(fmtDate(u.created_at))}</p></div><button class="btn btn-ghost" data-close aria-label="Chiudi">✕</button></div>
     <form id="uf" novalidate><div class="fgrid"><div class="field"><label for="u_name">Nome e cognome</label><input id="u_name" maxlength="120" value="${esc(u.full_name)}"></div><div class="field"><label for="u_prof">Categoria professionale</label><input id="u_prof" maxlength="100" value="${esc(u.profession || "")}"></div>
     <div class="field"><label for="u_mun">Zona</label><input id="u_mun" maxlength="100" value="${esc(u.municipality || "")}"></div><div class="field"><label for="u_phone">Telefono</label><input id="u_phone" type="tel" maxlength="40" value="${esc(u.phone || "")}"></div></div>
     <div class="actions"><button type="submit" class="btn btn-primary">Salva i dati</button></div></form>
     <p class="pmeta">Ruolo: <b>${ROLE[u.role]}</b> · Stato: <b>${u.active ? "attivo" : "disattivato"}</b></p><div id="dErr" class="notice error" role="alert" hidden></div>
     <div class="actions">${self ? "" : `<button class="btn btn-ghost" data-a="active">${u.active ? "Disattiva account" : "Riattiva account"}</button><button class="btn btn-ghost" data-a="role">${u.role === "admin" ? "Rendi professionista" : "Rendi amministratore"}</button>`}
     <button class="btn btn-ghost" data-a="export">Esporta i dati (JSON)</button>${self ? "" : '<button class="btn btn-danger" data-a="delete">Elimina account</button>'}</div>`);
    $("#uf", d).addEventListener("submit", async (e) => {
      e.preventDefault(); const name = $("#u_name", d).value.trim(); if (name.length < 2) return fail(d, "Inserisci il nome.");
      const { error } = await ctx.sb.from("profiles").update({ full_name: name, profession: $("#u_prof", d).value.trim() || null, municipality: $("#u_mun", d).value.trim() || null, phone: $("#u_phone", d).value.trim() || null }).eq("id", u.id);
      if (error) return fail(d, error.message); d.close(); toast("Dati aggiornati."); load();
    });
    d.addEventListener("click", async (e) => {
      const a = e.target.closest("[data-a]")?.dataset.a; if (!a) return; let body, ok = "Operazione eseguita.";
      if (a === "active") { if (u.active && !confirm("Disattivare l'account? La persona non potrà più accedere.")) return; body = { action: "set_active", user_id: u.id, active: !u.active }; ok = u.active ? "Account disattivato." : "Account riattivato."; }
      else if (a === "role") { if (!confirm(u.role === "admin" ? "Togliere i permessi di amministratore?" : "Dare a questa persona i permessi di AMMINISTRATORE? Vedrà tutti i dati reali.")) return; body = { action: "set_role", user_id: u.id, role: u.role === "admin" ? "professional" : "admin" }; ok = "Ruolo aggiornato."; }
      else if (a === "delete") { if (!confirm(`Eliminare DEFINITIVAMENTE l'account di ${u.full_name} con i suoi immobili, richieste e foto? L'operazione non si può annullare.`)) return; body = { action: "delete", user_id: u.id, confirm: true }; ok = "Account eliminato."; }
      else body = { action: "export", user_id: u.id };
      const r = await fn(ctx.sb, "admin-users", body); if (!r.ok) return fail(d, r.data?.error || "Operazione non riuscita.");
      if (a === "export") { downloadFile(`dati-${u.alias_code}.json`, JSON.stringify(r.data, null, 2), "application/json"); return toast("Dati esportati."); }
      d.close(); toast(ok); load();
    });
  }
  list.addEventListener("click", (e) => { const c = e.target.closest(".pcard"); if (c) openUser(S.rows.find((x) => x.id === c.dataset.id)); });
  $("#scope").addEventListener("change", (e) => { S.scope = e.target.value; S.page = 0; load(); });
  let t; $("#search").addEventListener("input", (e) => { clearTimeout(t); t = setTimeout(() => { S.q = e.target.value; S.page = 0; load(); }, 300); });
  $("#prev").addEventListener("click", () => { S.page--; load(); scrollTo(0, 0); }); $("#next").addEventListener("click", () => { S.page++; load(); scrollTo(0, 0); });
  $("#csv").addEventListener("click", async () => {
    const { data, error } = await filtered(ctx.sb.from("profiles").select(COLS)).order("full_name", { ascending: true }).range(0, 4999);
    if (error) return toast("Esportazione non riuscita."); downloadCsv("professionisti.csv", ["Nome", "Email", "Codice", "Categoria", "Zona", "Telefono", "Ruolo", "Stato", "Iscrizione"], data.map((u) => [u.full_name, u.email, u.alias_code, u.profession, u.municipality, u.phone, ROLE[u.role], u.active ? "Attivo" : "Disattivato", u.created_at]));
  });
  await load();
}
