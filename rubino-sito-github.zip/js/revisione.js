import { $, esc, renderHeader, requireSession } from "./core.js?v=4";
import { cardsHtml, firstPaths, openDetail, ownerLabels, signed } from "./property-ui.js?v=4";
const ctx = await requireSession();
if (ctx) {
  renderHeader("in-revisione", ctx.profile, ctx.sb);
  const admin = ctx.profile.role === "admin", list = $("#list");
  $("#title").textContent = admin ? "Annunci da revisionare" : "I tuoi annunci in revisione";
  $("#sub").textContent = admin ? "Approva o rifiuta (con motivazione) gli annunci inviati dai professionisti. Dal più vecchio al più recente." : "Lo stato dei tuoi annunci inviati e di quelli rifiutati, con la motivazione. Aprine uno per correggerlo e reinviarlo.";
  async function load() {
    list.innerHTML = '<p class="state">Caricamento…</p>';
    let q = ctx.sb.from("properties").select("id,title,municipality,category,listing_type,price,surface_sqm,rooms,status,submitted_by,rejection_reason,created_at,property_photos(storage_path,position)");
    q = admin ? q.in("status", ["submitted", "in_review"]).order("created_at", { ascending: true }) : q.eq("submitted_by", ctx.user.id).in("status", ["submitted", "in_review", "rejected"]).order("created_at", { ascending: false });
    const { data, error } = await q.limit(100);
    if (error) { list.innerHTML = '<p class="state err">Impossibile caricare gli annunci. Riprova tra poco.</p>'; return; }
    if (!data.length) { list.innerHTML = `<div class="state"><p>${admin ? "Nessun annuncio in attesa di revisione." : "Non hai annunci in revisione o rifiutati."}</p></div>`; return; }
    const [urls, owners] = await Promise.all([signed(ctx.sb, firstPaths(data)), ownerLabels(ctx, data)]);
    list.innerHTML = `<div class="pgrid">${cardsHtml(data, urls, owners, ctx)}</div>`;
  }
  list.addEventListener("click", (e) => { const c = e.target.closest(".pcard"); if (c) openDetail(ctx, c.dataset.id, load); });
  await load();
}
