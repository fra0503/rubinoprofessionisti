import { $, configured, getClient } from "./core.js?v=4";
const msg = $("#msg"), form = $("#form"), lead = $("#lead");
const show = (t, k = "error") => { msg.className = "notice " + k; msg.textContent = t; msg.hidden = false; };
if (!configured) { lead.textContent = ""; show("Recupero non disponibile: collegamento a Supabase non configurato.", "warn"); }
else {
  const sb = await getClient();
  // Supabase legge il token di recupero dall'URL e crea una sessione temporanea
  let ready = false;
  const open = () => { if (ready) return; ready = true; lead.textContent = "Scegli la nuova password."; form.hidden = false; $("#pw").focus(); };
  sb.auth.onAuthStateChange((ev) => { if (ev === "PASSWORD_RECOVERY") open(); });
  setTimeout(async () => { if (ready) return; const { data: { session } } = await sb.auth.getSession(); if (session) open(); else { lead.textContent = ""; show("Link non valido o scaduto. Richiedi un nuovo link dalla pagina di accesso."); } }, 1500);
  form.addEventListener("submit", async (e) => {
    e.preventDefault(); msg.hidden = true;
    const pw = $("#pw").value;
    if (pw.length < 10) return show("La password deve avere almeno 10 caratteri.");
    if (pw !== $("#pw2").value) return show("Le due password non coincidono.");
    const btn = $("#btn"); btn.disabled = true;
    const { error } = await sb.auth.updateUser({ password: pw });
    if (error) { btn.disabled = false; return show("Impossibile aggiornare la password. Il link potrebbe essere scaduto."); }
    await sb.auth.signOut(); location.replace("/accesso?ok=password");
  });
}
