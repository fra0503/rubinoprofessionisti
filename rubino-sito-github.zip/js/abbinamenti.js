// Abbinamenti: riservati all'amministratore. Sono SUGGERIMENTI automatici, non decisioni.
import { $, esc, renderHeader, requireSession, toast } from "./core.js?v=4";
import { openDetail, price } from "./property-ui.js?v=4";
import { RSTATUS, money, openRequest } from "./request-ui.js?v=4";
const ctx = await requireSession();
if (ctx && ctx.profile.role !== "admin") location.replace("/panoramica");
else if (ctx) {
  renderHeader("abbinamenti", ctx.profile, ctx.sb);
  const list = $("#list"), MS = { suggested: "Da valutare", confirmed: "Confermato", dismissed: "Respinto" }; let filter = "suggested";
  async function load() {
    list.innerHTML = '<p class="state">Caricamento…</p>';
    let q = ctx.sb.from("matches").select("id,score,reasons,status,notes,property_id,request_id,properties(id,title,municipality,price,listing_type,submitted_by),client_requests(id,title,municipality,need,budget_min,budget_max,submitted_by)");
    if (filter) q = q.eq("status", filter);
    const { data, error } = await q.order("score", { ascending: false }).limit(100);
    if (error) { list.innerHTML = '<p class="state err">Impossibile caricare gli abbinamenti. Riprova tra poco.</p>'; return; }
    if (!data.length) { list.innerHTML = `<div class="state"><p>${filter === "suggested" ? "Nessun suggerimento da valutare. Premi «Aggiorna suggerimenti» per cercare nuovi abbinamenti." : "Nessun abbinamento in questo stato."}</p></div>`; return; }
    const ids = [...new Set(data.flatMap((m) => [m.properties?.submitted_by, m.client_requests?.submitted_by]).filter(Boolean))];
    const { data: pr } = await ctx.sb.from("profiles").select("id,full_name,alias_code").in("id", ids); const nm = {}; (pr || []).forEach((p) => (nm[p.id] = `${p.full_name} · ${p.alias_code}`));
    list.innerHTML = data.map((m) => { const p = m.properties || {}, r = m.client_requests || {};
      return `<article class="mrow" data-id="${esc(m.id)}"><div class="mscore"><b>${esc(m.score)}</b><span>/100</span><span class="badge b-${m.status === "confirmed" ? "approved" : m.status === "dismissed" ? "rejected" : "submitted"}">${esc(MS[m.status])}</span></div>
      <div class="mcols"><div><p class="eyebrow">Immobile</p><b class="ptitle">${esc(p.title)}</b><p class="pmeta">${esc(p.municipality)} · ${esc(price(p.price, p.listing_type))}</p><p class="powner">${esc(nm[p.submitted_by] || "")}</p><button class="btn btn-ghost" data-open-p="${esc(p.id)}">Apri immobile</button></div>
      <div><p class="eyebrow">Richiesta</p><b class="ptitle">${esc(r.title)}</b><p class="pmeta">${esc(r.municipality)} · ${r.need === "buy" ? "Acquisto" : "Affitto"} · ${esc(money(r.budget_min, r.budget_max))}</p><p class="powner">${esc(nm[r.submitted_by] || "")}</p><button class="btn btn-ghost" data-open-r="${esc(r.id)}">Apri richiesta</button></div></div>
      <p class="why"><b>Perché è stato suggerito:</b> ${(m.reasons || []).map(esc).join(" · ")}</p>
      <div class="field"><label for="n_${esc(m.id)}">Note (solo per te)</label><input id="n_${esc(m.id)}" maxlength="1000" value="${esc(m.notes || "")}"></div>
      <div class="actions">${m.status !== "confirmed" ? '<button class="btn btn-primary" data-set="confirmed">Conferma</button>' : ""}${m.status !== "dismissed" ? '<button class="btn btn-ghost" data-set="dismissed">Respingi</button>' : ""}${m.status !== "suggested" ? '<button class="btn btn-ghost" data-set="suggested">Rimetti da valutare</button>' : ""}</div></article>`; }).join("");
  }
  list.addEventListener("click", async (e) => {
    const op = e.target.closest("[data-open-p]"), orq = e.target.closest("[data-open-r]"), st = e.target.closest("[data-set]");
    if (op) return openDetail(ctx, op.dataset.openP, load); if (orq) return openRequest(ctx, orq.dataset.openR, load);
    if (!st) return; const row = st.closest(".mrow"), id = row.dataset.id;
    const { error } = await ctx.sb.from("matches").update({ status: st.dataset.set, notes: row.querySelector("input").value.trim() || null }).eq("id", id);
    if (error) return toast("Operazione non riuscita: " + error.message); toast("Abbinamento aggiornato."); load();
  });
  $("#filter").addEventListener("change", (e) => { filter = e.target.value; load(); });
  $("#refresh").addEventListener("click", async (e) => {
    e.target.disabled = true; const { data, error } = await ctx.sb.rpc("refresh_matches"); e.target.disabled = false;
    if (error) return toast("Impossibile aggiornare i suggerimenti: " + error.message);
    toast(data ? (data === 1 ? "Trovato 1 nuovo suggerimento." : `Trovati ${data} nuovi suggerimenti.`) : "Nessun nuovo suggerimento."); load();
  });
  await load();
}
